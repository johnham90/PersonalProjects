[John Ham], [A01041999], [D], [2018.3.1]

This assignment is [100]% complete.


------------------------
Question one (PhoneNumbers) status:

[complete]

------------------------
Question two (CylinderStats) status:

[complete]

------------------------
Question three (Cylinder) status:

[complete]

------------------------
Question four (Box) status:

[complete]

------------------------
Question five (Email) status:

[complete]
