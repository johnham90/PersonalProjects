[John Ham], [A01041999], [D], [2018.02.08]

This assignment is [100]% complete.


------------------------
Question one (Change) status:

[Complete]

------------------------
Question two (SecondsConvert) status:

[Complete]

------------------------
Question three (Arithmetic) status:

[Complete]

------------------------
Question four (Cube) status:

[Complete]

------------------------
Question five (Pack) status:

[Complete]
