[John Ham], [A01041999], [D], [04/11/2018]

This assignment is [100]% complete.


------------------------
Question one (Statistics) status:

[complete]

------------------------
Question two (DrawStar) status:

[complete]

------------------------
Question three (TestMIXChar) status:

[complete]
